# mistiCRAFT — Supabase Setup

This is the Supabase-backed version of the site (Postgres + Auth + Storage
instead of Firebase). Every page — home, shop, product, cart, checkout,
account, our story, and the workshop admin — reads and writes real data in
real time. Follow these steps in order.

> **Updating from an earlier copy?** `schema.sql` is safe to re-run in
> full any time — every statement uses `if not exists` / `drop policy if
> exists` guards, so re-running it just adds what's missing (Leadership
> table, Settings table, order logistics columns) without touching your
> existing data. Just paste the whole file into SQL Editor and run again.

## 1. Create a Supabase project

1. Go to <https://supabase.com/dashboard> and create a new project (pick
   any region close to your customers).
2. Once it's ready, go to **Project Settings → API**.
3. Copy the **Project URL** and the **anon / public** key (not the
   `service_role` key — that one must never be used in browser code).
4. Open `supabase-init.js` in this folder and paste both into
   `MISTI_SUPABASE_URL` / `MISTI_SUPABASE_ANON_KEY`.

## 2. Turn on auth methods

**Authentication → Providers**:
- **Email** — enable it.
- **Anonymous Sign-Ins** — enable it (Authentication → Sign In / Providers,
  depending on dashboard version). This is what lets a shopper's cart work
  before they create an account.

**Authentication → Sign In / Up settings** — decide on **"Confirm email"**:
- **ON (default)**: more secure, but a new shopper must click a link in
  their inbox before their account is fully active — they'll see "check
  your email" after signing up.
- **OFF**: instant account activation, closer to a typical guest checkout
  flow. Turn this off if you'd rather not have that extra step.

## 3. Run the schema

Go to **SQL Editor → New query**, paste in the entire contents of
`schema.sql`, and click **Run**. This one script creates every table, all
Row Level Security policies, the two storage buckets (`product-images`,
`artisan-images`) with their access policies, and turns on realtime for
the tables that need live updates. Nothing else to configure.

## 4. Create your admin account (do this before sharing the site!)

The catalog (products/artisans) seeds itself automatically **the first
time an admin loads the dashboard** — so sign in as admin once before
regular shoppers visit, or they'll see an empty shop.

1. Open `account.html` and use **Create Account** to sign up with your own
   email (or use `admin.html`'s sign-in form — either works).
   - If "Confirm email" is ON, check your inbox and click the link first.
2. In the Supabase dashboard, go to **Authentication → Users**, find your
   account, and copy its **User UID**.
3. Go to **Table Editor → admins → Insert row**. Set `uid` to the UID you
   copied. The `email` column is optional (just for your own reference).
4. Open `admin.html` and sign in with the same account. You should see the
   full dashboard, and your starter catalog (12 products, 2 artisans) gets
   created automatically.

Repeat step 3 for any teammate's UID to give them admin access too. There's
no self-serve "make me an admin" button on purpose.

## 5. Set up real payments (Razorpay)

Checkout now takes real payments through Razorpay instead of only
simulating them. This needs two small server-side functions (Supabase
Edge Functions) because a payment gateway's secret key must never sit in
browser code — the two functions in `supabase/functions/` hold that key
server-side, verify the payment really happened, and only then create the
order. Regular signed-in users can no longer insert an order row directly
(that permission was removed on purpose) — orders only ever get created
by `verify-razorpay-payment` after checking a real payment signature.

**a) Get Razorpay keys**
1. Create an account at <https://dashboard.razorpay.com/signup>.
2. Settings → API Keys → generate a **Key ID** and **Key Secret**. Start
   in **Test Mode** (top-right toggle) so you can check out with
   [Razorpay's test cards/UPI IDs](https://razorpay.com/docs/payments/payments/test-card-upi-details/)
   before going live — switch to Live Mode + live keys once you're ready
   to accept real payments.

**b) Install the Supabase CLI and link your project** (one-time, needs
Node.js installed on your computer):
```
npm install -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_REF
```
Your project ref is the part of your Project URL before `.supabase.co`.

**c) Set your Razorpay keys as function secrets** (never put these in any
HTML/JS file — this is the one place they belong):
```
supabase secrets set RAZORPAY_KEY_ID=rzp_test_xxxxxxxx
supabase secrets set RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxx
```

**d) Deploy the two functions:**
```
supabase functions deploy create-razorpay-order
supabase functions deploy verify-razorpay-payment
```
That's it — no other config. Both functions read your Supabase URL and
keys automatically; only the Razorpay keys needed setting manually.

**e) Test it:** open checkout.html, add something to the bag, and pay
with a [Razorpay test card](https://razorpay.com/docs/payments/payments/test-card-upi-details/)
(while still in Test Mode). A successful test payment should create a
real row in `customer_orders` with `payment_status = paid`.

## 6. Put the site online

Any static host works (Netlify, Vercel, Firebase Hosting, S3, GitHub
Pages, etc.) — this is plain HTML/CSS/JS, no build step, no server.

## What's new in this update

- **Leadership section** (Our Story page) — manage Founder/CEO cards from
  Admin → Leadership, same pattern as Artisan Profiles (add/edit, photo
  upload, live on the storefront instantly).
- **Order logistics** — Admin → Customer Orders → "Set"/"Edit" under the
  Logistics column lets you attach a transporter name + tracking ID to
  any order. It shows up for the customer in Account → Order History and
  Live Tracking automatically.
- **Store Settings** (Admin → Settings) — shipping fee, store contact
  email/phone, and a default transporter name, all editable without
  touching code. Checkout now reads the shipping fee from here live.
- **Invoices** — every order gets a "Download Invoice" button (on the
  checkout confirmation screen and on each past order in Account → Order
  History), generating a PDF client-side via jsPDF (loaded from a CDN,
  no extra setup needed).
- **Real payments (Razorpay)** — checkout now actually charges a card/UPI
  through Razorpay via two Supabase Edge Functions (section 5), which also
  closes a real gap: previously any signed-in visitor could create an
  order row directly (e.g. via browser devtools) without paying anything.
  Orders are now only ever created after a server-verified payment.

## What's real vs. simplified

- **Payments are real** (Razorpay, Card + UPI) as of the setup in section
  5 above — until you complete that section, checkout will show a clear
  "payments not configured" error rather than silently faking success.
- **One saved address per account**, not a full multi-address book.
- **Order tracking** shows real status (Pending → Processing → Shipped →
  Delivered) but no carrier-level tracking events.
- **Guest carts** use an anonymous Supabase session tied to that browser.
  If someone checks out without an account, the order still saves, but
  they'll only see it again under "Order History" if they sign up in that
  same browser before clearing site data.
- `product.html` still shows one fixed product rather than a `?id=` page
  per product — a pre-existing template limitation, unrelated to the
  backend.
- Signing up may require an email-confirmation click depending on your
  step 2 setting — see above.

## Troubleshooting

- **"Payments are not configured yet on the server"** — Razorpay secrets
  (step 5c) haven't been set, or the functions (step 5d) haven't been
  deployed yet.
- **Checkout button does nothing / console shows "Razorpay is not
  defined"** — `checkout.razorpay.com/v1/checkout.js` didn't load, likely
  blocked by an ad-blocker or offline connection.
- **Payment succeeds in Razorpay but no order appears** — check the
  `verify-razorpay-payment` function's logs (`supabase functions logs
  verify-razorpay-payment` or via Dashboard → Edge Functions → Logs) for
  the real error; the checkout page will also show a message with the
  payment ID so you can look it up in the Razorpay dashboard.
- **"Supabase config is still a placeholder" in the console** — step 1
  isn't done yet.
- **Products/pages stay empty** — an admin needs to load the dashboard
  once first (step 4).
- **`new row violates row-level security policy`** — schema.sql wasn't run
  (step 3), or you're trying to write to a table your account isn't
  allowed to (e.g. editing products without being in `admins`).
- **Realtime updates don't show up without a refresh** — check
  **Database → Replication** in the dashboard and confirm the table is
  listed under `supabase_realtime`; schema.sql adds this automatically,
  but a project created before running it may need a manual toggle there.
- **Stuck after signup on "check your email"** — that's expected if
  "Confirm email" is on (step 2). Turn it off for instant activation.
